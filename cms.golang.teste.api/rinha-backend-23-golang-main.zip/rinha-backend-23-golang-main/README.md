# rinha-backend-23-golang

Implementation of https://github.com/zanfranceschi/rinha-de-backend-2023-q3 contest with golang, postgres and redis
