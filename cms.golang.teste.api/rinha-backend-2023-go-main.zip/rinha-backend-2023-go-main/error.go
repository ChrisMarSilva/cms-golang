package rinha

import "errors"

var ErrApelidoJaExiste = errors.New("apelido já existe")
