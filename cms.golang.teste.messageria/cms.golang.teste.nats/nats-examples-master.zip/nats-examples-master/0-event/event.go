package event

type Event struct {
	ID  int    `json:"id"`
	Msg string `json:"msg"`
}
