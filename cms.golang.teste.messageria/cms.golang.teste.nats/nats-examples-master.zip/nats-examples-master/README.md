Repositório com exemplos utilizando o client Go do NATS
